# Hotkey Tabs

This is the source code for a firefox addon that allows for the quick switching and loading of commonly used website and webpages with Alt-number keyboard shortcuts. If the specified website or webpage is open, then firefox will switch to that tab, else it will open the site in a new tab.
